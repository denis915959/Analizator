# ESP32 BLE for Arduino
The Arduino IDE provides an excellent library package manager where versions of libraries can be downloaded and installed. This Github project provides the repository for the ESP32 BLE support for Arduino.

The original source of the project, **which is not maintained anymore**, can be found here: https://github.com/nkolban/esp32-snippets

Issues and questions should be raised here: https://github.com/espressif/arduino-esp32/issues <br> (please don't use https://github.com/nkolban/esp32-snippets/issues!)

Documentation for using the library can be found here: https://github.com/nkolban/esp32-snippets/tree/master/Documentation
