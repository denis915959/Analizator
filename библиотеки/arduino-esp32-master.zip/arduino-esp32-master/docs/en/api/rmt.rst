###
RMT
###

About
-----

.. note:: This is a work in progress project and this section is still missing. If you want to contribute, please see the `Contributions Guide <../contributing.html>`_.

Remote Control Transceiver (RMT) peripheral was designed to act as an infrared transceiver.

Example
-------

To get started with RMT, you can try:

RMT Write RGB LED
*****************

.. literalinclude:: ../../../libraries/ESP32/examples/RMT/RMTWrite_RGB_LED/RMTWrite_RGB_LED.ino
    :language: arduino


Complete list of `RMT examples <https://github.com/espressif/arduino-esp32/tree/master/libraries/ESP32/examples/RMT>`_.
